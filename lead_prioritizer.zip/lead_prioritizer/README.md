# 🚀 Smart Lead Prioritizer

This is a Streamlit-based tool built for Caprae Capital's AI-Readiness Challenge. It takes a CSV file of B2B leads and scores them based on presence of contact info, LinkedIn, and relevance to AI/SaaS.

## 🧠 Features
- Upload B2B leads CSV
- Score leads based on:
  - Email presence
  - LinkedIn presence
  - AI/SaaS keywords in company
  - Website availability
- View sorted leads by priority
- Download prioritized leads

## 📦 How to Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 📁 Sample CSV Format
```csv
email,linkedin,company,website
contact@xyz.com,https://linkedin.com/in/sample,XYZ AI Solutions,https://xyz.com
,,ABC Enterprises,
john@example.com,,AIWorks,
```

## ✅ Tech Stack
- Python
- Streamlit
- Pandas
